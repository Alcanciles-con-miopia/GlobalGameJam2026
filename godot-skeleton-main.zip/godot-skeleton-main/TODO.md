> análogo a onenable() cuando ha acabado el fade

